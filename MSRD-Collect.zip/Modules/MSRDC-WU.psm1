﻿<#
.SYNOPSIS
   Module for extended installed Windows Updates report

.DESCRIPTION
   Collects information on installed Windows Updates and generates a report in .html format

.NOTES
   Author     : Robert Klemencz
   Requires   : MSRD-Collect.ps1
   Version    : See MSRD-Collect.ps1 version
   Feedback   : https://aka.ms/MSRD-Collect-Feedback
#>

$msrdLogPrefix = "Core"
$WUFile = $global:msrdSysInfoLogFolder + $global:msrdLogFilePrefix + "UpdateHistory.html"
$Script:WUErrors

Function msrdPrintUpdate ([string]$Category,[string]$ID,[string]$Operation,[string]$Date,[string]$ClientID,[string]$InstalledBy,[string]$OperationResult,[string]$Title,[string]$Description,[string]$HResult,[string]$UnmappedResultCode) {

	$Category = if ($Category -eq "QFE hotfix") { "Other updates not listed in history" } else { $Category }

	if (-not [String]::IsNullOrEmpty($ID)) {
		$NumberHotFixID = msrdToNumber $ID
		if ($NumberHotFixID.Length -gt 5) { $SupportLink = "http://support.microsoft.com/kb/$NumberHotFixID" }
	} else {
		$ID = ""
		$SupportLink = ""
	}

	if (-not [String]::IsNullOrEmpty($Title)) {
		if (($Title -like "*Security Update*System*") -or ($Title -like "*Cumulative Update*System*") -or ($Title -like "*Mise à jour cumulative*Windows*")) {
			$Title = "<b>" + $Title.Trim() + "</b>"
		} else {
			$Title = $Title.Trim()
		}
	} else {
		$Title = ""
	}

	$Description = if (-not [String]::IsNullOrEmpty($Description)) { $Description.Trim() } else { "" }

	$tdcircle = switch($OperationResult) {
        'Completed successfully' { "circle_green" }
        'Operation was aborted' { "circle_red" }
		'Completed with errors' { "circle_red" }
		'Failed to complete' { "circle_red" }
        'In progress' { "circle_white" }
        default { "circle_white" }
	}

	if ((-not [String]::IsNullOrEmpty($HResult)) -and ($HResult -ne 0)) {
		$HResultHex = msrdConvertToHex $HResult
		$HResultArray = msrdGetWUErrorCodes $HResultHex

		$errmsg = "Error code: $HResultHex"

		if ($null -ne $HResultArray) {
			$errmsg = $errmsg + " (" + $HResultArray[0] + " - " + $HResultArray[1] + ")"
		}

		$HResultHex2 = msrdConvertToHex $UnmappedResultCode
		$errmsg = "<tr><td width='10px'><div class='circle_red'></div></td><td colspan='3'></td><td colspan='3' style='background-color: #FFFFDD'>$errmsg [$HResultHex2]</td></tr>"
	}

	$DiagMessage = "<tr>
		<td width='10px'><div class='$tdcircle'></div></td>
		<td width='17%' style='padding-left: 5px;'>$Category</td>
		<td width='11%'>$Date</td>
		<td width='6%'>$Operation</td>
		<td width='11%'>$OperationResult</td>
		<td width='7%'><a href='$SupportLink' target='_blank'>$ID</a></td>
		<td><span title='$Description' style='cursor: pointer'>$Title</span></td>
	</tr>"

	msrdAddContentToHTML $WUFile $DiagMessage
	if ($errmsg) { msrdAddContentToHTML $WUFile $errmsg }
}

Function msrdGetHotFixFromRegistry {
	$RegistryHotFixList = @{}
	$UpdateRegistryKeys = @("HKLM:\SOFTWARE\Microsoft\Updates")

	#if $OSArchitecture -ne X86 , should be 64-bit machine. we also need to check HKLM:\SOFTWARE\Wow6432Node\Microsoft\Updates
	if($OSArchitecture -ne "X86")
	{
		$UpdateRegistryKeys += "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Updates"
	}

	foreach($RegistryKey in $UpdateRegistryKeys) {
		If(Test-Path $RegistryKey) {
			$AllProducts = Get-ChildItem $RegistryKey -Recurse | Where-Object {$_.Name.Contains("KB") -or $_.Name.Contains("Q")}

			foreach($subKey in $AllProducts) {
				if($subKey.Name.Contains("KB") -or $subKey.Name.Contains("Q")) {
					$HotFixID = msrdGetHotFixID $subKey.Name

					if($RegistryHotFixList.Keys -notcontains $HotFixID) {
						$Category = [regex]::Match($subKey.Name,"Updates\\(?<Category>.*?)[\\]").Groups["Category"].Value
						$HotFix = @{HotFixID=$HotFixID;Category=$Category}
						foreach($property in $subKey.Property)
						{
							$HotFix.Add($property,$subKey.GetValue($property))
						}
						$RegistryHotFixList.Add($HotFixID,$HotFix)
					}
				}
			}
		}
	}
	return $RegistryHotFixList
}

Function msrdGetHotFixID ($strContainID) {
	return [System.Text.RegularExpressions.Regex]::Match($strContainID,"(KB|Q)\d+(v\d)?").Value
}

Function msrdToNumber ($strHotFixID) {
	return [System.Text.RegularExpressions.Regex]::Match($strHotFixID,"([0-9])+").Value
}

Function msrdFormatStr ([string]$strValue,[int]$NumberofChars) {

	if([String]::IsNullOrEmpty($strValue)) {
		$strValue = " "
		return $strValue.PadRight($NumberofChars," ")
	} else {
		if($strValue.Length -lt $NumberofChars) {
			return $strValue.PadRight($NumberofChars," ")
		} else {
			return $strValue.Substring(0,$NumberofChars)
		}
	}
}

# dates with dd/mm/yy hh:mm:ss
Function msrdFormatDateTime ($dtLocalDateTime,[Switch]$SortFormat) {

	if([string]::IsNullOrEmpty($dtLocalDateTime)) { return "" }

	if($SortFormat.IsPresent) {
		# Obtain dates on yyyymmdddhhmmss
		return Get-Date -Date $dtLocalDateTime -Format "yyyyMMddHHmmss"
	} else {
		return Get-Date -Date $dtLocalDateTime -Format G
	}
}

Function msrdValidatingDateTime ($dateTimeToValidate) {

	if([String]::IsNullOrEmpty($dateTimeToValidate)) { return $false }

	$ConvertedDateTime = Get-Date -Date $dateTimeToValidate

	if($null -ne $ConvertedDateTime) {
		if(((Get-Date) - $ConvertedDateTime).Days -le $NumberOfDays) { return $true }
	}

	return $false
}

# Query SID of an object using WMI and return the account name
Function msrdConvertSIDToUser([string]$strSID)  {

	if([string]::IsNullOrEmpty($strSID)) { return }

	if($strSID.StartsWith("S-1-5")) {
		$UserSIDIdentifier = New-Object System.Security.Principal.SecurityIdentifier `
    	($strSID)
		$UserNTAccount = $UserSIDIdentifier.Translate( [System.Security.Principal.NTAccount])
		if($UserNTAccount.Value.Length -gt 0) {
			return $UserNTAccount.Value
		} else {
			return $strSID
		}
	}
	return $strSID
}

Function msrdConvertToHex([int]$number) {
	return ("0x{0:x8}" -f $number)
}

Function msrdGetUpdateOperation($Operation) {

	switch ($Operation) {
		1 { return "Install" }
		2 { return "Uninstall" }
		Default { return "Unknown("+$Operation+")" }
	}
}

Function msrdGetUpdateResult($ResultCode) {

	switch ($ResultCode) {
		0 { return "Not started" }
		1 { return "In progress" }
		2 { return "Completed successfully" }
		3 { return "Completed with errors" }
		4 { return "Failed to complete" }
		5 { return "Operation was aborted" }
		Default { return "Unknown("+$ResultCode+")" }
	}
}

Function msrdGetWUErrorCodes($HResult) {

	if ($null -eq $Script:WUErrors) {

		$WUErrorsFilePath = "$global:msrdScriptpath\Config\MSRDC-WU.xml"

		if(Test-Path -Path $WUErrorsFilePath) {
			[xml] $Script:WUErrors = Get-Content $WUErrorsFilePath
		} else {
			"[Warning]: Did not find the Config\MSRDC-WU.xml file, cannot load all WU error code information" | Out-File -Append ($global:msrdErrorLogFile)
		}
	}

	$WUErrorNode = $Script:WUErrors.ErrV1.err | Where-Object {$_.n -eq $HResult}

	if ($null -ne $WUErrorNode) {
		$WUErrorCode = @()
		$WUErrorCode += $WUErrorNode.name
		$WUErrorCode += $WUErrorNode."#text"
		return $WUErrorCode
	}
	return $null
}


# Start here
Function msrdRunUEX_MSRDWU {

	msrdCreateLogFolder $global:msrdSysInfoLogFolder
	msrdLogMessage $LogLevel.Normal -LogPrefix $msrdLogPrefix -Message "Exporting Windows Update history"

	msrdHtmlInit $WUFile
	msrdHtmlHeader -htmloutfile $WUFile -title "Update History : $($env:computername)" -fontsize "11px"
    msrdHtmlBodyWU -htmloutfile $WUFile -title "Update History for $global:msrdFQDN"

	# Get updates from the com object
	Try {
		$Session = New-Object -ComObject Microsoft.Update.Session
		$Searcher = $Session.CreateUpdateSearcher()
		$HistoryCount = $Searcher.GetTotalHistoryCount()
	} Catch {
        msrdLogMessage $LogLevel.Error ("Error collecting updates information from Microsoft.Update.Session" + $_.Exception.Message)
		$HistoryCount = 0
    }

	if ($HistoryCount -gt 0) {
		$ComUpdateHistory = $Searcher.QueryHistory(1,$HistoryCount)
	} else {
		$ComUpdateHistory = @()
		"`nNo updates found on Microsoft.Update.Session`n" | Out-File -Append $global:msrdOutputLogFile
	}

	# Get updates from the Wmi object Win32_QuickFixEngineering
	$QFEHotFixList = New-Object "System.Collections.ArrayList"
	$QFEHotFixList.AddRange(@(Get-CimInstance -ClassName Win32_QuickFixEngineering))

	# Get updates from the regsitry keys
	$RegistryHotFixList = msrdGetHotFixFromRegistry

	# Format each update history to the stringbuilder
	foreach($updateEntry in $ComUpdateHistory) {

		# Do not list the updates on which the $updateEntry.ServiceID = '117CAB2D-82B1-4B5A-A08C-4D62DBEE7782' or '855e8a7c-ecb4-4ca3-b045-1dfa50104289'. These are Windows Store updates and are bringing inconsistent results
		if (($updateEntry.ServiceID -ne '117CAB2D-82B1-4B5A-A08C-4D62DBEE7782') -and ($updateEntry.ServiceID -ne '855e8a7c-ecb4-4ca3-b045-1dfa50104289')) {

			$HotFixID = msrdGetHotFixID $updateEntry.Title
			$HotFixIDNumber = msrdToNumber $HotFixID
			$strInstalledBy = ""

			if(($HotFixID -ne "") -or ($HotFixIDNumber -ne "")) {
				foreach($QFEHotFix in $QFEHotFixList) {
					if(($QFEHotFix.HotFixID -eq $HotFixID) -or ((msrdToNumber $QFEHotFix.HotFixID) -eq $HotFixIDNumber)) {
						$strInstalledBy = msrdConvertSIDToUser $QFEHotFix.InstalledBy

						#Remove the duplicate HotFix in the QFEHotFixList
						$QFEHotFixList.Remove($QFEHotFix)
						break
					}
				}
			}

			# Remove the duplicate HotFix in the RegistryHotFixList
			if ($RegistryHotFixList.Keys -contains $HotFixID) { $RegistryHotFixList.Remove($HotFixID) }

			$strCategory = ""
			if($updateEntry.Categories.Count -gt 0) { $strCategory = $updateEntry.Categories.Item(0).Name }

			if ([String]::IsNullOrEmpty($strCategory)) { $strCategory = "(None)" }

			$strOperation = msrdGetUpdateOperation $updateEntry.Operation
			$strDateTime = msrdFormatDateTime $updateEntry.Date
			$strResult = msrdGetUpdateResult $updateEntry.ResultCode

			msrdPrintUpdate -Category $strCategory -ID $HotFixID -Operation $strOperation -Date $strDateTime -ClientID $updateEntry.ClientApplicationID -InstalledBy $strInstalledBy -OperationResult $strResult -Title $updateEntry.Title -Description $updateEntry.Description -HResult $updateEntry.HResult -UnmappedResultCode $updateEntry.UnmappedResultCode
		}
	}

	msrdAddContentToHTML $WUFile "</table></div></details>
	<details open>
		<summary>
			<a name='QFE'></a><b>Other - QFE</b><span class='b2top'><a href='#'>^top</a></span>
		</summary>
		<div class='detailsP'>
			<table class='tduo'>
				<tr style='text-align: left;'>
					<th width='10px'><div class='circle_no'></div></th><th style='padding-left: 5px;'>Category</th><th>Date/Time</th><th>Operation</th><th>Result</th><th>KB</th><th>Description</th>
				</tr>"
	# Output the Non History QFEFixes
	foreach($QFEHotFix in $QFEHotFixList) {
		$strInstalledBy = msrdConvertSIDToUser $QFEHotFix.InstalledBy
		$strDateTime = msrdFormatDateTime $QFEHotFix.InstalledOn
		$strCategory = ""

		# Remove the duplicate HotFix in the RegistryHotFixList
		if($RegistryHotFixList.Keys -contains $QFEHotFix.HotFixID) {
			$strCategory = $RegistryHotFixList[$QFEHotFix.HotFixID].Category
			$strRegistryDateTime = msrdFormatDateTime $RegistryHotFixList[$QFEHotFix.HotFixID].InstalledDate

			if ([String]::IsNullOrEmpty($strInstalledBy)) {
				$strInstalledBy = $RegistryHotFixList[$QFEHotFix.HotFixID].InstalledBy
			}

			$RegistryHotFixList.Remove($QFEHotFix.HotFixID)
		}

		if ([string]::IsNullOrEmpty($strCategory)) {
			$strCategory = "QFE hotfix"
		}

		if ($strDateTime.Length -eq 0) {
			$strDateTime = $strRegistryDateTime
		}

		if ([string]::IsNullOrEmpty($QFEHotFix.Status)) {
			$strResult = "Completed successfully"
		} else {
			$strResult = $QFEHotFix.Status
		}

		msrdPrintUpdate -Category $strCategory -ID $QFEHotFix.HotFixID -Operation "Install" -Date $strDateTime -ClientID "" -InstalledBy $strInstalledBy -OperationResult $strResult -Title $QFEHotFix.Description -Description $QFEHotFix.Caption
	}

	msrdAddContentToHTML $WUFile "</table></div></details>
	<details open>
		<summary>
			<a name='REG'></a><b>Other - Registry</b><span class='b2top'><a href='#'>^top</a></span>
		</summary>
		<div class='detailsP'>
			<table class='tduo'>
				<tr style='text-align: left;'>
					<th width='10px'><div class='circle_no'></div></th><th style='padding-left: 5px;'>Category</th><th>Date/Time</th><th>Operation</th><th>Result</th><th>KB</th><th>Description</th>
				</tr>"
	# Generating information for updates found on registry
	foreach ($key in $RegistryHotFixList.Keys) {
		$strCategory = $RegistryHotFixList[$key].Category
		$HotFixID = $RegistryHotFixList[$key].HotFixID
		$strDateTime = $RegistryHotFixList[$key].InstalledDate
		$strInstalledBy = $RegistryHotFixList[$key].InstalledBy
		$ClientID = $RegistryHotFixList[$key].InstallerName

		if ($HotFixID.StartsWith("Q")) {
			$Description = $RegistryHotFixList[$key].Description
		} else {
			$Description = $RegistryHotFixList[$key].PackageName
		}

		if ([string]::IsNullOrEmpty($Description)) {
			$Description = $strCategory
		}

		msrdPrintUpdate -Category $strCategory -ID $HotFixID -Operation "Install" -Date $strDateTime -ClientID $ClientID -InstalledBy $strInstalledBy -OperationResult "Completed successfully" -Title $strCategory -Description $Description
	}

	# Creating output files
	msrdHtmlEnd $WUFile

	$Session = $null
}

Export-ModuleMember -Function msrdRunUEX_MSRDWU
# SIG # Begin signature block
# MIIoUgYJKoZIhvcNAQcCoIIoQzCCKD8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB2b0Ld4RUVk+8A
# mmERX6IcpSIR6TZJqNobFpfH2R+lnKCCDYUwggYDMIID66ADAgECAhMzAAADri01
# UchTj1UdAAAAAAOuMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwODU5WhcNMjQxMTE0MTkwODU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQD0IPymNjfDEKg+YyE6SjDvJwKW1+pieqTjAY0CnOHZ1Nj5irGjNZPMlQ4HfxXG
# yAVCZcEWE4x2sZgam872R1s0+TAelOtbqFmoW4suJHAYoTHhkznNVKpscm5fZ899
# QnReZv5WtWwbD8HAFXbPPStW2JKCqPcZ54Y6wbuWV9bKtKPImqbkMcTejTgEAj82
# 6GQc6/Th66Koka8cUIvz59e/IP04DGrh9wkq2jIFvQ8EDegw1B4KyJTIs76+hmpV
# M5SwBZjRs3liOQrierkNVo11WuujB3kBf2CbPoP9MlOyyezqkMIbTRj4OHeKlamd
# WaSFhwHLJRIQpfc8sLwOSIBBAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhx/vdKmXhwc4WiWXbsf0I53h8T8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMTgzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGrJYDUS7s8o0yNprGXRXuAnRcHKxSjFmW4wclcUTYsQZkhnbMwthWM6cAYb/h2W
# 5GNKtlmj/y/CThe3y/o0EH2h+jwfU/9eJ0fK1ZO/2WD0xi777qU+a7l8KjMPdwjY
# 0tk9bYEGEZfYPRHy1AGPQVuZlG4i5ymJDsMrcIcqV8pxzsw/yk/O4y/nlOjHz4oV
# APU0br5t9tgD8E08GSDi3I6H57Ftod9w26h0MlQiOr10Xqhr5iPLS7SlQwj8HW37
# ybqsmjQpKhmWul6xiXSNGGm36GarHy4Q1egYlxhlUnk3ZKSr3QtWIo1GGL03hT57
# xzjL25fKiZQX/q+II8nuG5M0Qmjvl6Egltr4hZ3e3FQRzRHfLoNPq3ELpxbWdH8t
# Nuj0j/x9Crnfwbki8n57mJKI5JVWRWTSLmbTcDDLkTZlJLg9V1BIJwXGY3i2kR9i
# 5HsADL8YlW0gMWVSlKB1eiSlK6LmFi0rVH16dde+j5T/EaQtFz6qngN7d1lvO7uk
# 6rtX+MLKG4LDRsQgBTi6sIYiKntMjoYFHMPvI/OMUip5ljtLitVbkFGfagSqmbxK
# 7rJMhC8wiTzHanBg1Rrbff1niBbnFbbV4UDmYumjs1FIpFCazk6AADXxoKCo5TsO
# zSHqr9gHgGYQC2hMyX9MGLIpowYCURx3L7kUiGbOiMwaMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGiMwghofAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAOuLTVRyFOPVR0AAAAA
# A64wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIHG
# D4FCoBDbQDpOSzZ+uYyGHf/Y8pEWzAF9BJsaHWe3MEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAM1VwZ0l6HAOz8qVfnI1WhaGVh5pzhcmzTTD/
# 2Qgh0knusJyyseYlhoDWIad7UtAxgM3d7pakE6OHii1ggLDGO4pF60FuLSGeECjd
# KD4H8Drn/joIqooQ3AXYKn9BgsJtW/H9InOznuZ7ZH4Qw7x3NNZgk5CJQDWIjkuc
# IkBpkjEtHOc9yP3vwLv7xKSer6iaj3xYMGauG6GoGO0q/cDzAvix327SmRiHnkt9
# 3b6iXTXVv6/jOfFDntBESaUGb9aJjZDATxKV5JewA8BSOD/sPcMoLo7fNsuyrKUy
# ux9//RzAfXAiJSr0ZpAfI2BHWoxj/zRDwUGAg961fOs29nweq6GCF60wghepBgor
# BgEEAYI3AwMBMYIXmTCCF5UGCSqGSIb3DQEHAqCCF4YwgheCAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFaBgsqhkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCD9b/TI1a8Lzyg2GAQCLIWLbnaJYJaVfoNz
# CLNLUsJUewIGZsZPsUK+GBMyMDI0MDkwOTEwMjEzMC42NDZaMASAAgH0oIHZpIHW
# MIHTMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsT
# Hm5TaGllbGQgVFNTIEVTTjoyRDFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCEfswggcoMIIFEKADAgECAhMzAAAB/XP5
# aFrNDGHtAAEAAAH9MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMB4XDTI0MDcyNTE4MzExNloXDTI1MTAyMjE4MzExNlowgdMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jv
# c29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVs
# ZCBUU1MgRVNOOjJEMUEtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# oWWs+D+Ou4JjYnRHRedu0MTFYzNJEVPnILzc02R3qbnujvhZgkhp+p/lymYLzkQy
# G2zpxYceTjIF7HiQWbt6FW3ARkBrthJUz05ZnKpcF31lpUEb8gUXiD2xIpo8YM+S
# D0S+hTP1TCA/we38yZ3BEtmZtcVnaLRp/Avsqg+5KI0Kw6TDJpKwTLl0VW0/23sK
# ikeWDSnHQeTprO0zIm/btagSYm3V/8zXlfxy7s/EVFdSglHGsUq8EZupUO8XbHzz
# 7tURyiD3kOxNnw5ox1eZX/c/XmW4H6b4yNmZF0wTZuw37yA1PJKOySSrXrWEh+H6
# ++Wb6+1ltMCPoMJHUtPP3Cn0CNcNvrPyJtDacqjnITrLzrsHdOLqjsH229Zkvndk
# 0IqxBDZgMoY+Ef7ffFRP2pPkrF1F9IcBkYz8hL+QjX+u4y4Uqq4UtT7VRnsqvR/x
# /+QLE0pcSEh/XE1w1fcp6Jmq8RnHEXikycMLN/a/KYxpSP3FfFbLZuf+qIryFL0g
# EDytapGn1ONjVkiKpVP2uqVIYj4ViCjy5pLUceMeqiKgYqhpmUHCE2WssLLhdQBH
# dpl28+k+ZY6m4dPFnEoGcJHuMcIZnw4cOwixojROr+Nq71cJj7Q4L0XwPvuTHQt0
# oH7RKMQgmsy7CVD7v55dOhdHXdYsyO69dAdK+nWlyYcCAwEAAaOCAUkwggFFMB0G
# A1UdDgQWBBTpDMXA4ZW8+yL2+3vA6RmU7oEKpDAfBgNVHSMEGDAWgBSfpxVdAF5i
# XYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENB
# JTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRp
# bWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsF
# AAOCAgEAY9hYX+T5AmCrYGaH96TdR5T52/PNOG7ySYeopv4flnDWQLhBlravAg+p
# jlNv5XSXZrKGv8e4s5dJ5WdhfC9ywFQq4TmXnUevPXtlubZk+02BXK6/23hM0TSK
# s2KlhYiqzbRe8QbMfKXEDtvMoHSZT7r+wI2IgjYQwka+3P9VXgERwu46/czz8IR/
# Zq+vO5523Jld6ssVuzs9uwIrJhfcYBj50mXWRBcMhzajLjWDgcih0DuykPcBpoTL
# lOL8LpXooqnr+QLYE4BpUep3JySMYfPz2hfOL3g02WEfsOxp8ANbcdiqM31dm3vS
# heEkmjHA2zuM+Tgn4j5n+Any7IODYQkIrNVhLdML09eu1dIPhp24lFtnWTYNaFTO
# fMqFa3Ab8KDKicmp0AthRNZVg0BPAL58+B0UcoBGKzS9jscwOTu1JmNlisOKkVUV
# kSJ5Fo/ctfDSPdCTVaIXXF7l40k1cM/X2O0JdAS97T78lYjtw/PybuzX5shxBh/R
# qTPvCyAhIxBVKfN/hfs4CIoFaqWJ0r/8SB1CGsyyIcPfEgMo8ceq1w5Zo0JfnyFi
# 6Guo+z3LPFl/exQaRubErsAUTfyBY5/5liyvjAgyDYnEB8vHO7c7Fg2tGd5hGgYs
# +AOoWx24+XcyxpUkAajDhky9Dl+8JZTjts6BcT9sYTmOodk/SgIwggdxMIIFWaAD
# AgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3Nv
# ZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIy
# MjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5
# vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64
# NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhu
# je3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl
# 3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPg
# yY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I
# 5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2
# ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/
# TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy
# 16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y
# 1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6H
# XtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMB
# AAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQW
# BBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30B
# ATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYB
# BAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBL
# oEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggr
# BgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1Vffwq
# reEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27
# DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pv
# vinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9Ak
# vUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWK
# NsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2
# kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+
# c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep
# 8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+Dvk
# txW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1Zyvg
# DbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/
# 2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYIDVjCCAj4CAQEwggEBoYHZpIHW
# MIHTMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsT
# Hm5TaGllbGQgVFNTIEVTTjoyRDFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAoj0WtVVQUNSK
# oqtrjinRAsBUdoOggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDANBgkqhkiG9w0BAQsFAAIFAOqJMSMwIhgPMjAyNDA5MDkwODMyMzVaGA8yMDI0
# MDkxMDA4MzIzNVowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA6okxIwIBADAHAgEA
# AgIp7DAHAgEAAgIT6TAKAgUA6oqCowIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgor
# BgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUA
# A4IBAQAwXvApEkMECpfwESUbttJnLNt3sVcNapAIY7ENGeRxj5HZOjivk0I1YgFc
# bNu55tcH92TD/XUlYQUhUbB4cwrDNqcW68OUNA+eB/VIoUlmA0IJi+hQ/ubN5iRS
# ByWmwsp1IusFzYlq4j2dRmKnHn56YVnKAV5Ghbh4QOudmSSaR/iFjVCYoIoXTmMJ
# 5WqLrAowikvZVytSNSwfEiLz2WuVd1+0TSFeg1EOZVlORe/EGpd0y8UpwbpFQE71
# rnt/7+EIB8qgYmtuNumEgieSaTjq7oCEJpo0uq1CMI4M9OZ8QpqOys+V5bxfmznO
# y9/eWXFXbXhdBEEhqWQha4HcQV8iMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAH9c/loWs0MYe0AAQAAAf0wDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgqUy5ZMfXC9y4dOB6qyb77ejY9OtmFdh0JCYyYuKo6JIwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCCAKEgNyUowvIfx/eDfYSupHkeF1p6GFwjKBs8l
# RB4NRzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# /XP5aFrNDGHtAAEAAAH9MCIEIBq00xymYPfgKY656IeCiJjhcLCzQXqQgdckPEuH
# XgW0MA0GCSqGSIb3DQEBCwUABIICAH8nFHgPy5cTKV1+N4UgJgFp3hpTgHkjbpyB
# j6oWOCEhhRbLOtePnqyqPKC6qjcbwrhVD9YdE9q+h7cGoaON0aJuS2xzNlN4wvBe
# 407RdwhvvN/0fXB/YFCDxyPOdVVRfWhIDwO3/422UQTIwgSJU4/kkuSkM+hw3KgT
# aXhoeUcyQkZ1Kj5x7ENPH1R4m0w4mtvgVboZGHSw7kc3s/T8Lkiwzi4/WIn6zRhE
# ZroCEIcITZtPp69yMb9MDG4aBdymw7ZOhTBQGokoHDYwUuPLymeZ40rJP8kGyrfs
# uSXt6bCB3ae0lZJ7ud1OReQpPZjwWqGrEw/op9qpNB7f4+1uVCvAcwf24ziBQQ7O
# lE2smHoy1b8QDxBUUqjPydfXe/AbXC+d6193oqVZIzNgFn7hSYAaETchyLQOO/q/
# RZRp2h+1QeqSiLflq+yoiF9HZzAD2CkMGO634tBbcPf54P5VXC2+07WhSMrUPflA
# ChrNkNeNHb+wl/Cgmh+DcGEOb3UyRnZvtt+B7WIw0YHhs62S9pRGUcFSj2md4Hup
# bXG/lZarHT72IOj5jobUw9lO971rRWdibpSgbFah5tot1u/U2T7ZhEI9eIg6UFKF
# u1Era2JDkEJY0Npw7s3VAA5mEQjfcdHNuLaYqRIfGpKi60c8C9RxTIZExr6chd9U
# ZoJioIxQ
# SIG # End signature block
