<#
.SYNOPSIS
   Scenario module for collecting Microsoft Remote Desktop Profiles related data

.DESCRIPTION
   Collect Profiles related troubleshooting data (incl. FSLogix, OneDrive)

.NOTES
   Author     : Robert Klemencz
   Requires   : MSRD-Collect.ps1
   Version    : See MSRD-Collect.ps1 version
   Feedback   : https://aka.ms/MSRD-Collect-Feedback
#>

$msrdLogPrefix = "Profiles"
$ProfilesLogFolder = $global:msrdBasicLogFolder + "Profiles\"
$FSLogixLogFolder = $ProfilesLogFolder + "FSLogix\"

Function msrdGetFSLogixLogFiles {
    Param([Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFilePath,
        [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$LogFileDestination)

    #get FSLogix log files
    msrdLogMessage $LogLevel.Normal -LogPrefix $msrdLogPrefix -Message "Copy-Item $LogFilePath"
    if (Test-path -path "$LogFilePath") {
        Try {
            msrdCreateLogFolder $LogFileDestination
            Copy-Item $LogFilePath $LogFileDestination -Recurse -ErrorAction Continue 2>&1 | Out-Null
        } Catch {
            $failedCommand = $_.InvocationInfo.Line.TrimStart()
            msrdLogException ("$(msrdGetLocalizedText "errormsg") $failedCommand") -ErrObj $_
        }
    } else {
        msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "'$LogFilePath' folder not found"
    }
}

Function msrdGetFSLogixCompact {

    #get FSLogix compact action logs
    msrdLogMessage $LogLevel.Normal -LogPrefix $msrdLogPrefix -Message "FSLogix VHD compaction events"
    $startTime = (Get-Date).AddDays(-5)

    $diskCompactionEvents = Get-WinEvent -FilterHashtable @{StartTime = $startTime; logname = 'Microsoft-FSLogix-Apps/Operational'; id = 57} -ErrorAction SilentlyContinue

    if ($diskCompactionEvents) {
        $compactionMetrics = $diskCompactionEvents | Select-Object `
            @{l="Timestamp";e={$_.TimeCreated}},`
            @{l="Path";e={$_.Properties[0].Value}},`
            @{l="WasCompacted";e={$_.Properties[1].Value}},`
            @{l="TimeSpent(ms)";e={[math]::round($_.Properties[7].Value,2)}},`
            @{l="MaxSupportedSize(MB)";e={[math]::round($_.Properties[2].Value,2)}},`
            @{l="MinSupportedSize(MB)";e={[math]::round($_.Properties[3].Value,2)}},`
            @{l="InitialSize(MB)";e={[math]::round($_.Properties[4].Value,2)}},`
            @{l="FinalSize(MB)";e={[math]::round($_.Properties[5].Value,2)}},`
            @{l="SavedSpace(MB)";e={[math]::round($_.Properties[6].Value,2)}}

        $compactionMetrics | Out-File -FilePath ($FSLogixLogFolder + $global:msrdLogFilePrefix + "vhdCompactionEvents.txt") -Append
    } else {
        msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "FSLogix VHD compaction events not found"
    }
}

Function msrdGetFSLogixRedirXML {

    #get FSLogix redirection xml information
    msrdLogMessage $LogLevel.Normal -LogPrefix $msrdLogPrefix -Message "FSLogix Redirections XML"

    if (msrdTestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "RedirXMLSourceFolder") {
        $pxml = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "RedirXMLSourceFolder"
        $pxmlfile = $pxml + "\redirections.xml"
        $pxmlout = $FSLogixLogFolder + $env:computername + "_redirections.xml"

        if (Test-Path -Path $pxmlfile) {
            Try {
                Copy-Item $pxmlfile $pxmlout -ErrorAction Continue 2>&1 | Out-Null
            } Catch {
                msrdLogException ("Error: An exception occurred in msrdGetFSLogixRedirXML $pxmlfile.") -ErrObj $_
            }
        } else {
            msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "'$pxmlfile' log not found"
        }
    } else {
        msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "RedirXMLSourceFolder registry key not found"
    }
}

Function msrdGetProfilesRegKeys {

    msrdCreateLogFolder $msrdRegLogFolder
    $regs = @{
        'HKCU:\SOFTWARE\Microsoft\Office' = 'SW-MS-Office'
        'HKLM:\SOFTWARE\Microsoft\OneDrive' = 'SW-MS-OneDrive'
        'HKCU:\SOFTWARE\Microsoft\OneDrive' = 'SW-MS-OneDrive'
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\Credential Providers' = 'SW-MS-Win-CV-Auth-CredProviders'
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders' = 'SW-MS-Win-CV-Explorer-ShellFolders'
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders' = 'SW-MS-Win-CV-Explorer-ShellFolders'
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' = 'SW-MS-Win-CV-Explorer-UserShellFolders'
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' = 'SW-MS-Win-CV-Explorer-UserShellFolders'
        'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList' = 'SW-MS-WinNT-CV-ProfileList'
        'HKLM:\SOFTWARE\Microsoft\Windows Search' = 'SW-MS-WindowsSearch'
        'HKCU:\Volatile Environment' = 'VolatileEnvironment'
    }

    if ($global:msrdAVD -or $global:msrdRDS) {
        $regs += @{
            'HKLM:\SYSTEM\CurrentControlSet\Enum\SCSI\Disk&Ven_Msft&Prod_Virtual_Disk' = 'System-CCS-Enum-SCSI-ProdVirtualDisk'
            'HKLM:\SOFTWARE\FSLogix' = 'SW-FSLogix'
            'HKCU:\SOFTWARE\FSLogix' = 'SW-FSLogix'
        }
    }

    msrdGetRegKeys -LogPrefix $msrdLogPrefix -RegHashtable $regs
}

Function msrdGetProfilesEventLogs {

    msrdCreateLogFolder $global:msrdEventLogFolder
    $logs = @{
        'Microsoft-Windows-User Profile Service/Operational' = 'UserProfileService-Operational'
    }

    if ($global:msrdAVD -or $global:msrdRDS) {
        $logs += @{
            'Microsoft-Windows-VHDMP-Operational' = 'VHDMP-Operational'
            'Microsoft-FSLogix-Apps/Admin' = 'FSLogix-Apps-Admin'
            'Microsoft-FSLogix-Apps/Operational' = 'FSLogix-Apps-Operational'
            'Microsoft-FSLogix-CloudCache/Admin' = 'FSLogix-CloudCache-Admin'
            'Microsoft-FSLogix-CloudCache/Operational' = 'FSLogix-CloudCache-Operational'
        }

        $eventlog = "Microsoft-Windows-Ntfs/Operational"
        msrdLogMessage $LogLevel.Normal -LogPrefix $msrdLogPrefix -Message "Filtered $eventlog event logs"
        $ntfslog = $global:msrdEventLogFolder + $env:computername + "_NTFS_filtered.evtx"

        if (Get-WinEvent -ListLog $eventlog -ErrorAction SilentlyContinue) {
            Try {
                wevtutil epl $eventlog $ntfslog "/q:*[System[(EventID=4 or EventID=142)]]"
            } Catch {
                msrdLogException "Error: An error occurred while exporting the NTFS logs" -ErrObj $_
            }
        } else {
            msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "Event log '$eventlog' not found"
        }
    }

    msrdGetEventLogs -LogPrefix $msrdLogPrefix -EventHashtable $logs
}

Function msrdGetFSLogixData {

    if (Test-path -path "$env:ProgramFiles\FSLogix") {

        msrdCreateLogFolder $FSLogixLogFolder
        msrdGetFSLogixCompact
        msrdGetFSLogixRedirXML

        if (msrdTestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Logging\" -value "LogDir") {
            $fslogixlogsloc = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Logging\" -name "LogDir"
        } else {
            $fslogixlogsloc = "$env:ProgramData\FSLogix\Logs"
        }

        if (Test-Path -path $fslogixlogsloc) {
            msrdGetFSLogixLogFiles -LogFilePath "$fslogixlogsloc\*" -LogFileDestination ($FSLogixLogFolder + "Logs")

            $Commands = @(
                "tree '$fslogixlogsloc' /f 2>&1 | Out-File -Append '" + $FSLogixLogFolder + "Logs\" + $global:msrdLogFilePrefix + "tree_ProgFiles-FSLogixLogs.txt'"
            )
            msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        } else {
            msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "'$fslogixlogsloc' folder not found"
        }

        $fslogixrulesloc = "$env:ProgramFiles\FSLogix\Apps\Rules"
        if (Test-Path -path $fslogixrulesloc) {
            msrdCreateLogFolder ($FSLogixLogFolder + "AppsRules")
            msrdGetFSLogixLogFiles -LogFilePath "$fslogixrulesloc\*" -LogFileDestination ($FSLogixLogFolder + "AppsRules")

            $Commands = @(
                "tree '$fslogixrulesloc' /f 2>&1 | Out-File -Append '" + $FSLogixLogFolder + "AppsRules\" + $global:msrdLogFilePrefix + "tree_ProgFiles-FSLogixAppsRules.txt'"
            )
            msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        } else {
            msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "'$fslogixrulesloc' folder not found"
        }

        $fslogixCompiledrulesloc = "$env:ProgramFiles\FSLogix\Apps\CompiledRules"
        if (Test-Path -path $fslogixCompiledrulesloc) {
            msrdCreateLogFolder ($FSLogixLogFolder + "AppsRules")
            $Commands = @(
                "tree '$fslogixCompiledrulesloc' /f 2>&1 | Out-File -Append '" + $FSLogixLogFolder + "AppsRules\" + $global:msrdLogFilePrefix + "tree_ProgFiles-FSLogixAppsCompiledRules.txt'"
            )
            msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        } else {
            msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "'$fslogixCompiledrulesloc' folder not found"
        }

        $fslogixfrxloc = "$env:ProgramFiles\FSLogix\Apps\frx.exe"
        if (Test-path -path $fslogixfrxloc) {
            $Commands = @(
                "cmd /c '$fslogixfrxloc' version 2>&1 | Out-File -Append '" + $FSLogixLogFolder + $global:msrdLogFilePrefix + "frx-list.txt'"
                "cmd /c '$fslogixfrxloc' list-redirects 2>&1 | Out-File -Append '" + $FSLogixLogFolder + $global:msrdLogFilePrefix + "frx-list.txt'"
                "cmd /c '$fslogixfrxloc' list-rules 2>&1 | Out-File -Append '" + $FSLogixLogFolder + $global:msrdLogFilePrefix + "frx-list.txt'"
            )
            msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        } else {
            msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "'$fslogixfrxloc' not found"
        }

        #if applicable, removing accountname and account key from the exported CCDLocations reg key for security reasons
        $ccdRegOutP = $msrdRegLogFolder + $global:msrdLogFilePrefix + "HKLM-SW-FSLogix.txt"
        if (Test-Path -path $ccdRegOutP) {
            $ccdContentP = Get-Content -Path $ccdRegOutP
            $ccdReplaceP = foreach ($ccdItemP in $ccdContentP) {
                if ($ccdItemP -like "*CCDLocations*") {
                    $var1P = $ccdItemP -split ";"
                    $var2P = foreach ($varItemP in $var1P) {
                                if ($varItemP -like "AccountName=*") { $varItemP = "AccountName=xxxxxxxxxxxxxxxx"; $varItemP }
                                elseif ($varItemP -like "AccountKey=*") { $varItemP = "AccountKey=xxxxxxxxxxxxxxxx"; $varItemP }
                                else { $varItemP }
                            }
                    $var3P = $var2P -join ";"
                    $var3P
                } else {
                    $ccdItemP
                }
            }
            $ccdReplaceP | Set-Content -Path $ccdRegOutP
        }

        $ccdRegOutO = $msrdRegLogFolder + $global:msrdLogFilePrefix + "HKLM-SW-Policies.txt"
        if (Test-Path -path $ccdRegOutO) {
            $ccdContentO = Get-Content -Path $ccdRegOutO
            $ccdReplaceO = foreach ($ccdItemO in $ccdContentO) {
                if ($ccdItemO -like "*CCDLocations*") {
                    $var1O = $ccdItemO -split ";"
                    $var2O = foreach ($varItemO in $var1O) {
                                if ($varItemO -like "AccountName=*") { $varItemO = "AccountName=xxxxxxxxxxxxxxxx"; $varItemO }
                                elseif ($varItemO -like "AccountKey=*") { $varItemO = "AccountKey=xxxxxxxxxxxxxxxx"; $varItemO }
                                else { $varItemO }
                            }
                    $var3O = $var2O -join ";"
                    $var3O
                } else {
                    $ccdItemO
                }
            }
            $ccdReplaceO | Set-Content -Path $ccdRegOutO
        }

        msrdGetLocalGroupMembership -logPrefix $msrdLogPrefix -groupName "FSLogix ODFC Exclude List" -outputFile ($FSLogixLogFolder + $global:msrdLogFilePrefix + "LocalGroupsMembership.txt")
        msrdGetLocalGroupMembership -logPrefix $msrdLogPrefix -groupName "FSLogix ODFC Include List" -outputFile ($FSLogixLogFolder + $global:msrdLogFilePrefix + "LocalGroupsMembership.txt")
        msrdGetLocalGroupMembership -logPrefix $msrdLogPrefix -groupName "FSLogix Profile Exclude List" -outputFile ($FSLogixLogFolder + $global:msrdLogFilePrefix + "LocalGroupsMembership.txt")
        msrdGetLocalGroupMembership -logPrefix $msrdLogPrefix -groupName "FSLogix Profile Include List" -outputFile ($FSLogixLogFolder + $global:msrdLogFilePrefix + "LocalGroupsMembership.txt")

        if (msrdTestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "VHDLocations") {
            $pvhd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "VHDLocations"

            $Commands = @(
                "icacls $pvhd 2>&1 | Out-File -Append " + $FSLogixLogFolder + $global:msrdLogFilePrefix + "folderPermissions.txt"
            )
            msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        }

        if (msrdTestRegistryValue -path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -value "VHDLocations") {
            $ovhd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Policies\FSLogix\ODFC\" -name "VHDLocations"

            $Commands = @(
                "icacls $ovhd 2>&1 | Out-File -Append " + $FSLogixLogFolder + $global:msrdLogFilePrefix + "folderPermissions.txt"
            )
            msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        }


        #Collecting AAD Kerberos Auth for FSLogix
        $Commands = @(
                "klist get krbtgt 2>&1 | Out-File -Append " + $ProfilesLogFolder + $global:msrdLogFilePrefix + "klist-get-krbtgt.txt"
            )
        msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

        if (msrdTestRegistryValue -path "HKLM:\SOFTWARE\FSLogix\Profiles\" -value "VHDLocations") {
                $pvhd = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\FSLogix\Profiles\" -name "VHDLocations" -ErrorAction SilentlyContinue
                $pconPath = $pvhd.split("\")[2]
                if ($pconPath) {
                    $Commands = @(
                        "klist get cifs/$pconPath 2>&1 | Out-File -Append " + $FSLogixLogFolder + $global:msrdLogFilePrefix + "klist-get-cifs-ProfileVHDLocations.txt"
                    )
                    msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
                }
        } else {
            msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "'HKLM:\SOFTWARE\FSLogix\Profiles\VHDLocations' not found. Skipping 'klist get cifs/...'"
        }

        $fslpnpout = $FSLogixLogFolder + $global:msrdLogFilePrefix + "PnpUtil-export-pnpstate.pnp"
        $Commands = @(
            "pnputil /export-pnpstate '$fslpnpout' 2>&1 | Out-Null"
        )
        msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True

    } else {
        msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "'$env:ProgramFiles\FSLogix' folder not found"
    }
}

#Collect VHDX config consistency
Function msrdVirtualDiskRegConsistency {

    $registryPath = "HKLM:\System\CurrentControlSet\Enum\SCSI\Disk&Ven_Msft&Prod_Virtual_Disk"
    $diskInfo = Get-ChildItem -Path $registryPath -ErrorAction SilentlyContinue

    if ($diskInfo) {
        $headerVDRC = @"
======================================
"Consistency check for '$registryPath\' (relevant for mounting UPD or FSlogix profile disks)
======================================`n
"@
        $headerVDRC | Out-File -Append ($ProfilesLogFolder + $global:msrdLogFilePrefix + "VirtualDiskRegConsistency.txt")

        $missingCounter = 0
        foreach ($item in $diskInfo) {
            $missingValues = @()

            $classGuidValue = $item.GetValue("ClassGUID")
            if ($null -eq $classGuidValue) { $missingValues += "ClassGUID" }

            $MfgValue = $item.GetValue("Mfg")
            if ($null -eq $MfgValue) { $missingValues += "Mfg" }

            $ServiceValue = $item.GetValue("Service")
            if ($null -eq $ServiceValue) { $missingValues += "Service" }

            if ($null -eq $classGuidValue -or $null -eq $MfgValue -or $null -eq $ServiceValue) {
                $global:msrdSetWarning = $true; $global:msrdIssueCounter += 1;
                $missingString = $missingValues -join " / "
                "[WARNING] Subkey $($item.PSChildName) is missing the following critical registry value(s): '$missingString'" | Out-File -Append ($ProfilesLogFolder + $global:msrdLogFilePrefix + "VirtualDiskRegConsistency.txt")
                $missingCounter += 1
            } else {
                "Subkey $($item.PSChildName) has all expected registry values (ClassGUID, Mfg, Service) present" | Out-File -Append ($ProfilesLogFolder + $global:msrdLogFilePrefix + "VirtualDiskRegConsistency.txt")
            }
        }

        if ($missingCounter -eq 0) {
            "`n`n--------------------------------------`nNo missing registry values found under '$registryPath'" | Out-File -Append ($ProfilesLogFolder + $global:msrdLogFilePrefix + "VirtualDiskRegConsistency.txt")
        } else {
            "`n`n--------------------------------------`n[WARNING] $missingCounter subkeys are missing one or more critical registry values. Users may run into issues while mounting their UPD or FSLogix profile disks during logon." | Out-File -Append ($ProfilesLogFolder + $global:msrdLogFilePrefix + "VirtualDiskRegConsistency.txt")
        }
    } else {
		msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "Registry path '$registryPath' was not found"
    }
}

# Collecting User Profiles troubleshooting data
Function msrdCollectUEX_AVDProfilesLog {
    param( [bool[]]$varsProfiles )

    if ($true -contains $varsProfiles) {
        if ($global:msrdSilentMode -eq 1) { msrdLogMessage $LogLevel.Normal "`n" -NoDate } else { " " | Out-File -Append $global:msrdOutputLogFile }
        msrdLogMessage $LogLevel.Info "$(msrdGetLocalizedText 'profilesmsg')" -silentException
        msrdCreateLogFolder $ProfilesLogFolder
    }

    if ($varsProfiles[0]) {
        if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect User Profiles related event logs" }
        msrdGetProfilesEventLogs
    } #profiles event logs

    if ($varsProfiles[1]) {
        if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect User Profiles related registry keys" }
        msrdGetProfilesRegKeys
    } #profiles reg keys

    if ($varsProfiles[2]) {
        if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect WhoAmI information" }
        msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray ("Whoami /all 2>&1 | Out-File -Append '" + $ProfilesLogFolder + $global:msrdLogFilePrefix + "WhoAmI-all.txt'") -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } #whoami information

    if ($varsProfiles[3] -and ($global:msrdAVD -or $global:msrdRDS)) {
        if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect FSLogix data" }
        msrdGetFSLogixData
    } #fslogix logs

    if ($varsProfiles[4] -and ($global:msrdAVD -or $global:msrdRDS)) {
        if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect Virtual Disk registry consistency information" }
        msrdVirtualDiskRegConsistency
    } #virtual disk registry consistency
}

Export-ModuleMember -Function msrdCollectUEX_AVDProfilesLog
# SIG # Begin signature block
# MIInzgYJKoZIhvcNAQcCoIInvzCCJ7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBhSodWUOiuIyjF
# 7Vi+3TzPbzqIVUFNTfXYq3zD7V+ehqCCDYUwggYDMIID66ADAgECAhMzAAADri01
# UchTj1UdAAAAAAOuMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwODU5WhcNMjQxMTE0MTkwODU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQD0IPymNjfDEKg+YyE6SjDvJwKW1+pieqTjAY0CnOHZ1Nj5irGjNZPMlQ4HfxXG
# yAVCZcEWE4x2sZgam872R1s0+TAelOtbqFmoW4suJHAYoTHhkznNVKpscm5fZ899
# QnReZv5WtWwbD8HAFXbPPStW2JKCqPcZ54Y6wbuWV9bKtKPImqbkMcTejTgEAj82
# 6GQc6/Th66Koka8cUIvz59e/IP04DGrh9wkq2jIFvQ8EDegw1B4KyJTIs76+hmpV
# M5SwBZjRs3liOQrierkNVo11WuujB3kBf2CbPoP9MlOyyezqkMIbTRj4OHeKlamd
# WaSFhwHLJRIQpfc8sLwOSIBBAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhx/vdKmXhwc4WiWXbsf0I53h8T8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMTgzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGrJYDUS7s8o0yNprGXRXuAnRcHKxSjFmW4wclcUTYsQZkhnbMwthWM6cAYb/h2W
# 5GNKtlmj/y/CThe3y/o0EH2h+jwfU/9eJ0fK1ZO/2WD0xi777qU+a7l8KjMPdwjY
# 0tk9bYEGEZfYPRHy1AGPQVuZlG4i5ymJDsMrcIcqV8pxzsw/yk/O4y/nlOjHz4oV
# APU0br5t9tgD8E08GSDi3I6H57Ftod9w26h0MlQiOr10Xqhr5iPLS7SlQwj8HW37
# ybqsmjQpKhmWul6xiXSNGGm36GarHy4Q1egYlxhlUnk3ZKSr3QtWIo1GGL03hT57
# xzjL25fKiZQX/q+II8nuG5M0Qmjvl6Egltr4hZ3e3FQRzRHfLoNPq3ELpxbWdH8t
# Nuj0j/x9Crnfwbki8n57mJKI5JVWRWTSLmbTcDDLkTZlJLg9V1BIJwXGY3i2kR9i
# 5HsADL8YlW0gMWVSlKB1eiSlK6LmFi0rVH16dde+j5T/EaQtFz6qngN7d1lvO7uk
# 6rtX+MLKG4LDRsQgBTi6sIYiKntMjoYFHMPvI/OMUip5ljtLitVbkFGfagSqmbxK
# 7rJMhC8wiTzHanBg1Rrbff1niBbnFbbV4UDmYumjs1FIpFCazk6AADXxoKCo5TsO
# zSHqr9gHgGYQC2hMyX9MGLIpowYCURx3L7kUiGbOiMwaMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGZ8wghmbAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAOuLTVRyFOPVR0AAAAA
# A64wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEICU1
# sC1waMkYeY0j2gootgM7YhDLy8z44OM/8EWWAc8GMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAHlK9KjMeDF5atDvTofmsxRqpNOuzOQ/jCAoV
# YnLiXYoAm/MtaLKrKVtqTxoI6H4+NYzfq8MVqvO7Wpa3EVHPFx6etyhr4ZTu0XiJ
# IfYnciBo1whU/eEZ6Ly+0vSuFHBjjMPBUsCTDXBWch1sp/CYbIPcwuVH9ScJ0KO9
# 1I2P33ZFjZmyYJCS3A3WQ/Ky/F1/94fKFSpAl/p6eicMXZ+RPe+EbgDxhjOtdIgO
# SQshS/7BDsbyWgHfu3WKiNYsuyvEP3O8SL4Rwps8FGvMO2oPoJZvuwv8zkmMGRVQ
# QM2RgM9+vkAjsoSoqOLR8Jn0ZcOtqraEnzNIcj1TUfYMtw1RMaGCFykwghclBgor
# BgEEAYI3AwMBMYIXFTCCFxEGCSqGSIb3DQEHAqCCFwIwghb+AgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFZBgsqhkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCCM/v5sFLmi+XOfg8Lte3AbxrLFWa7tZG6+
# 8JjcijHMBgIGZsXgvFznGBMyMDI0MDkwOTEwMjEzMS41MjNaMASAAgH0oIHYpIHV
# MIHSMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIReDCCBycwggUPoAMCAQICEzMAAAHj372b
# mhxogyIAAQAAAeMwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwHhcNMjMxMDEyMTkwNzI5WhcNMjUwMTEwMTkwNzI5WjCB0jELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9z
# b2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL6k
# DWgeRp+fxSBUD6N/yuEJpXggzBeNG5KB8M9AbIWeEokJgOghlMg8JmqkNsB4Wl1N
# EXR7cL6vlPCsWGLMhyqmscQu36/8h2bx6TU4M8dVZEd6V4U+l9gpte+VF91kOI35
# fOqJ6eQDMwSBQ5c9ElPFUijTA7zV7Y5PRYrS4FL9p494TidCpBEH5N6AO5u8wNA/
# jKO94Zkfjgu7sLF8SUdrc1GRNEk2F91L3pxR+32FsuQTZi8hqtrFpEORxbySgiQB
# P3cH7fPleN1NynhMRf6T7XC1L0PRyKy9MZ6TBWru2HeWivkxIue1nLQb/O/n0j2Q
# Vd42Zf0ArXB/Vq54gQ8JIvUH0cbvyWM8PomhFi6q2F7he43jhrxyvn1Xi1pwHOVs
# bH26YxDKTWxl20hfQLdzz4RVTo8cFRMdQCxlKkSnocPWqfV/4H5APSPXk0r8Cc/c
# Mmva3g4EvupF4ErbSO0UNnCRv7UDxlSGiwiGkmny53mqtAZ7NLePhFtwfxp6ATIo
# jl8JXjr3+bnQWUCDCd5Oap54fGeGYU8KxOohmz604BgT14e3sRWABpW+oXYSCyFQ
# 3SZQ3/LNTVby9ENsuEh2UIQKWU7lv7chrBrHCDw0jM+WwOjYUS7YxMAhaSyOahpb
# udALvRUXpQhELFoO6tOx/66hzqgjSTOEY3pu46BFAgMBAAGjggFJMIIBRTAdBgNV
# HQ4EFgQUsa4NZr41FbehZ8Y+ep2m2YiYqQMwHwYDVR0jBBgwFoAUn6cVXQBeYl2D
# 9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1l
# LVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUB
# Af8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQAD
# ggIBALe+my6p1NPMEW1t70a8Y2hGxj6siDSulGAs4UxmkfzxMAic4j0+GTPbHxk1
# 93mQ0FRPa9dtbRbaezV0GLkEsUWTGF2tP6WsDdl5/lD4wUQ76ArFOencCpK5svE0
# sO0FyhrJHZxMLCOclvd6vAIPOkZAYihBH/RXcxzbiliOCr//3w7REnsLuOp/7vlX
# JAsGzmJesBP/0ERqxjKudPWuBGz/qdRlJtOl5nv9NZkyLig4D5hy9p2Ec1zaotiL
# iHnJ9mlsJEcUDhYj8PnYnJjjsCxv+yJzao2aUHiIQzMbFq+M08c8uBEf+s37YbZQ
# 7XAFxwe2EVJAUwpWjmtJ3b3zSWTMmFWunFr2aLk6vVeS0u1MyEfEv+0bDk+N3jms
# CwbLkM9FaDi7q2HtUn3z6k7AnETc28dAvLf/ioqUrVYTwBrbRH4XVFEvaIQ+i7es
# DQicWW1dCDA/J3xOoCECV68611jriajfdVg8o0Wp+FCg5CAUtslgOFuiYULgcxnq
# zkmP2i58ZEa0rm4LZymHBzsIMU0yMmuVmAkYxbdEDi5XqlZIupPpqmD6/fLjD4ub
# 0SEEttOpg0np0ra/MNCfv/tVhJtz5wgiEIKX+s4akawLfY+16xDB64Nm0HoGs/Gy
# 823ulIm4GyrUcpNZxnXvE6OZMjI/V1AgSAg8U/heMWuZTWVUMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAtQwggI9AgEBMIIBAKGB2KSB1TCB
# 0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAPYiXu8ORQ4hvKcuE
# 7GK0COgxWnqggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAN
# BgkqhkiG9w0BAQUFAAIFAOqIwgYwIhgPMjAyNDA5MDkwODM4MzBaGA8yMDI0MDkx
# MDA4MzgzMFowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA6ojCBgIBADAHAgEAAgIa
# gTAHAgEAAgIRdDAKAgUA6ooThgIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEE
# AYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GB
# AGT9YWxvttYNcQi44f/XDz2h84XpycmlXZYC5EOS18q8gmYxdbw23BfKEQ3BWPXH
# xWNxny3+a9AdFOXRiDKhKdcFf7R/bnhPhXMCMmNQt+Vhi0uZLlVlhjSzQAHqV1WG
# 3z68+KYSTUBetrEGwizt/89uPgmYp1TJH4Oj3FMprr+FMYIEDTCCBAkCAQEwgZMw
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHj372bmhxogyIAAQAA
# AeMwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAvBgkqhkiG9w0BCQQxIgQg106hGqf90AaVP2AHE48X8IcVeTU4cW9cfEtPcNGJ
# 4NAwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAz1COr5bD+ZPdEgQjWvcIW
# uDJcQbdgq8Ndj0xyMuYmKjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAAB49+9m5ocaIMiAAEAAAHjMCIEIGTTApXwhFVIzVqkHhs55TM5
# llR6+xeuabjFAEbTprN6MA0GCSqGSIb3DQEBCwUABIICACLZFnPqRHfx/UduqPpo
# +b+BYtr16g5TN+JlS88H34DgzVdtMrn2dT1H7b5KS/WHD/H62oFwZ7U6olzmwwxJ
# WupkRGCtoQ2AIpJ4bX7tZM+5LPEM8Ew3yYv3ci2jCXJSt0ehYJ9lTokZ3zAd17NQ
# wz5l9scOTkp5GIO2pwBm/91S+yh42wbv3W/FPg6mpS+AVOmnQTt31XX/osLWAIkG
# n2+kNp35IH4P0rQETvSbMCSPvdbLPiT6gqp7Q0RLKDi7orDm6W/OEPtSa5tY4OcN
# 8JmVKBGxyjp4JRyk9IGOBFYd4okxZLVxRDT4vLRQdIeaeBoPX7PcgdrDjYpOnunI
# XBEDUV+ZufpSBtJ4WZTC5TAqOuC1GCQIeDGvnsyM2m5lkgW8KT32xCo5dfaCK3b9
# dWPJvSwfThKrw/AYOuNcjhH8eMc6JDTdW4frFapRRTByChTqlr4mUFiEEb2mUj3B
# SfruHHxVudi28S+PNQQmzuJWq999oJXH4G39HMJfCg7l/DiEMq2QMm0O0fNkSMtb
# GaEOQhArnQKtCkXJTjh7RkD329Fuz+aV+GPpzAUAXsBJdZfLrywy5K2mTD9EzPGt
# Ix/jQR/q1Hgfk+6bob2dwPutWvkF0CKbEbV7AjM6K3Vruq7oBSDFuPiFmoCpITVn
# qbdOOC/C/i6ExeTHAniCyuJw
# SIG # End signature block
