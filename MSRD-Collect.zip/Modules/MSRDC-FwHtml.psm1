<#
.SYNOPSIS
   MSRD-Collect HTML functions

.DESCRIPTION
   Module for the MSRD-Collect html functions

.NOTES
   Author     : Robert Klemencz
   Requires   : MSRD-Collect.ps1
   Version    : See MSRD-Collect.ps1 version
   Feedback   : https://aka.ms/MSRD-Collect-Feedback
#>


#region HTML functions

Function msrdHtmlInit {
    param ($htmloutfile)

    #html report initialization
    msrdCreateLogFolder $global:msrdLogDir

    New-Item -Path $htmloutfile -ItemType File | Out-Null

    Set-Content $htmloutfile "<!DOCTYPE html>
<html>"
}

Function msrdHtmlHeader {
    param ($htmloutfile, $title, $fontsize)

    #html report header
msrdAddContentToHTML $htmloutfile "<head>
    <title>$title</title>
</head>
<style>
    .table-container { position: fixed; width: 100%; top: 0; left: 0; z-index: 1; background-color: white; }
    .WUtable-container { position: relative; display: inline-block; width: 100%; }
    BODY { font-family: Arial, Helvetica, sans-serif; font-size: $fontsize; }
    table { background-color: white; border: none; width: 100%; padding-left: 5px; padding-right: 5px; padding-bottom: 5px; }
    td { word-break: break-all; border: none; }
    th { border-bottom: solid 1px #CCCCCC; }

    .tduo { border: 1px solid #BBBBBB; background-color: white; vertical-align:top; border-radius: 5px; box-shadow: 1px 1px 2px 3px rgba(12,12,12,0.2); }
    .tduo tr:hover { background-color: #BBC3C6; }

    details > summary { background-color: #7D7E8C; color: white; cursor: pointer; padding: 5px; border:1px solid #BBBBBB; text-align: left; font-size: 13px; border-radius: 5px; }
    .detailsP { padding: 5px 5px 10px 15px; }

    .scroll { padding-top: 140px; box-sizing: border-box; }

    .cText { padding-left: 5px; }
    .cTable1-2 { padding-left: 5px; width: 12%; }
    .cTable1-3 { padding-left: 5px; width: 12%; }
    .cTable1-3b { width: 53%; }
    .cTable2-1 { padding-left: 5px; width: 65%; }
    .b2top a { color:white; float:right; text-decoration: none; }
    .menubutton { width: 150px; cursor: pointer; filter: drop-shadow(3px 3px 1px rgba(0, 0, 0, 0.25)) }

    .circle_green { vertical-align:top; padding-left: 5px; border: 1px solid #a1a1a1; padding: 5px 3px; background: #009933; border-radius: 100%; width: 5px; heigth: 5px }
    .circle_yellow { vertical-align:top; padding-left: 5px; border: 1px solid #a1a1a1; padding: 5px 3px; background: yellow; border-radius: 100%; width: 5px; heigth: 5px }
    .circle_red { vertical-align:top; padding-left: 5px; border: 1px solid #a1a1a1; padding: 5px 3px; background: red; border-radius: 100%; width: 5px; heigth: 5px }
    .circle_white { vertical-align:top; padding-left: 5px; border: 1px solid #a1a1a1; padding: 5px 3px; background: white; border-radius: 100%; width: 5px; heigth: 5px }
    .circle_no { vertical-align:top; padding-left: 5px; border: 1px solid white; padding: 5px 3px; background: white; border-radius: 100%; width: 5px; heigth: 5px }

    .circle_redCounter { display: inline-block; vertical-align: middle; width: 10px; height: 10px; border-radius: 50%; background-color: red; border: 1px solid #a1a1a1; margin-bottom: 2px; }
    .circle_yellowCounter { display: inline-block; vertical-align: middle; width: 10px; height: 10px; border-radius: 50%; background-color: yellow; border: 1px solid #a1a1a1; margin-bottom: 2px; }

    .dropdown-wrapper { background-color: white; position: fixed; cursor: pointer; display: flex; align-items: center; flex-direction: column; left: 50%; transform: translateX(-50%); width: 100%; margin: 0 auto; padding-bottom: 20px; padding-top: 5px;}
    .dropdown { position: relative; margin-right: 5px; }
	.dropdown button { background-color: #7D7E8C; color: #fff; border: none; border-radius: 5px; padding: 8px 14px; line-height: 14px; cursor: pointer; transition: background-color 0.3s; }
	.dropdown button a { text-decoration: none; color: #fff; }
	.dropdown-content { display: none; position: absolute; background-color: #fff; min-width: 160px; box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); z-index: 1; white-space: nowrap; }
	.dropdown-content a { padding: 10px; text-decoration: none; display: block; color: #000; }
    .dropdown:hover button { background-color: #5b5b5b; }
    .dropdown:hover .dropdown-content { display: block; }
    .dropdown:hover .dropdown-content a:hover { background-color: #BBC3C6; color: #000; }
    .dropdown:last-child { margin-right: 0; }

    .buttons-container { display: flex; justify-content: center; flex-wrap: wrap; }
    .text-container { text-align: center; margin-top: 5px; }
    .right-aligned-text { text-align: right; width: 100%; margin-right: 50px; }

    .legend-item { margin-bottom: 5px; }
    .circle { width: 10px; height: 10px; display: inline-block; margin-right: 5px; border-radius: 100%; }
    .green { background-color: green; border: 1px solid #a1a1a1; }
    .yellow { background-color: yellow; border: 1px solid #a1a1a1; }
    .red { background-color: red; border: 1px solid #a1a1a1; }
    .white { background-color: white; border: 1px solid #a1a1a1; }
    .info { background-color: transparent; }

    .circle-with-content { width: 10px; height: 10px; display: inline-block; margin-right: 5px; border-radius: 100%; position: relative; border: 1px solid #a1a1a1; }
    .circle-with-content::before { content: 'i'; font-size: 10px; color: #a1a1a1; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); }

    .legend-container { position: fixed; z-index: 1; display: none; width: 450px; padding: 10px; background-color: #fff; border: 1px solid #ccc; text-align: left; }
    .hide-show-all { display: inline-block; }
    .hidden { display: none; }
</style>"
}

Function msrdHtmlMenu {
    Param ($htmloutfile, [string]$CatText, [System.Collections.Generic.Dictionary[String,String]]$BtnTextAndId)

    if (-not $BtnTextAndId) {
            msrdAddContentToHTML $htmloutfile "<div class='dropdown'><button><a href='#$CatText'>$CatText</a></button></div>"
    } else {
        msrdAddContentToHTML $htmloutfile "<div class='dropdown'><button>$CatText</button><div class='dropdown-content'>"

        foreach ($txt in $BtnTextAndId.GetEnumerator()) {
            $btnLink = $txt.Value
            $btnText = $txt.Key
            msrdAddContentToHTML $htmloutfile "<a href='$btnLink'>$btnText</a>"
        }

        msrdAddContentToHTML $htmloutfile "</div></div>"
    }
}

Function msrdHtmlBodyDiag {
    Param ($htmloutfile, $title, [bool[]]$varsSystem, [bool[]]$varsAVDRDS, [bool[]]$varsInfra, [bool[]]$varsAD, [bool[]]$varsNET, [bool[]]$varsLogSec, [bool[]]$varsIssues, [bool[]]$varsOther)

    #html report body
    msrdAddContentToHTML $htmloutfile "
<body>
    <div class='table-container'>
        <div style='text-align:center;'><a name='TopDiag'></a><b><h3>$title</h3></b></div>
        <div class='dropdown-wrapper'>
            <div class='buttons-container'>
"

#region menu

    #Overview

    msrdHtmlMenu -htmloutfile $htmloutfile -CatText "Overview"

    #system
    if ($true -in $varsSystem) {
        $BtnsSystem = [System.Collections.Generic.Dictionary[String,String]]@{}

        if ($varsSystem[0]) { $BtnsSystem.Add("Core", "#DeploymentCheck") }
        if ($varsSystem[1]) { $BtnsSystem.Add("CPU Utilization and Handles", "#CPUCheck") }
        if ($varsSystem[2]) { $BtnsSystem.Add("Drives", "#DiskCheck") }
        if ($varsSystem[3]) { $BtnsSystem.Add("Graphics", "#GPUCheck") }
        if ($global:msrdTarget) { if ($varsSystem[4]) { $BtnsSystem.Add("Hyper-V Integration", "#HyperVCheck") } }
        if ($varsSystem[5]) { $BtnsSystem.Add("MUI / Languages", "#MUILangCheck") }
        if ($varsSystem[6]) { $BtnsSystem.Add("SSL / TLS", "#SSLCheck") }
        if ($varsSystem[7]) { $BtnsSystem.Add("User Account Control", "#UACCheck") }
        if ($varsSystem[8]) { $BtnsSystem.Add("Windows/Apps Installation", "#InstallerCheck") }
        if ($global:msrdTarget) { if ($varsSystem[9]) { $BtnsSystem.Add("Windows Activation / Licensing", "#KMSCheck") } }
        if ($global:msrdTarget) { if ($varsSystem[10]) { $BtnsSystem.Add("Windows Search", "#SearchCheck") } }
        if ($varsSystem[11]) { $BtnsSystem.Add("Windows Update", "#WUCheck") }
        if ($varsSystem[12]) { $BtnsSystem.Add("WinRM / PowerShell", "#WinRMPSCheck") }

        msrdHtmlMenu -htmloutfile $htmloutfile -CatText "System" -BtnTextAndId $BtnsSystem
    }

    #avd/rds/w365
    if ($true -in $varsAVDRDS) {
        $BtnsAVDRDS = [System.Collections.Generic.Dictionary[String,String]]@{}

        if ($varsAVDRDS[0]) { $BtnsAVDRDS.Add("Device and Resource Redirection", "#RedirCheck") }

        if (($global:msrdAVD -or $global:msrdRDS) -and $global:msrdTarget) { if ($varsAVDRDS[1]) { $BtnsAVDRDS.Add("FSLogix", "#ProfileCheck") } }

        if ($varsAVDRDS[2]) { $BtnsAVDRDS.Add("Multimedia", "#MultiMedCheck") }
        if ($varsAVDRDS[3]) { $BtnsAVDRDS.Add("Quick Assist / Remote Help", "#QACheck") }
        if ($global:msrdTarget) {
            if ($varsAVDRDS[4]) { $BtnsAVDRDS.Add("RDP / Listener", "#ListenerCheck") }
            if ($global:msrdOSVer -like "*Windows Server*") {
                if ($varsAVDRDS[5]) { $BtnsAVDRDS.Add("RDS Roles", "#RolesCheck") }
            }
        }
        if ($global:msrdSource) { if ($varsAVDRDS[6]) { $BtnsAVDRDS.Add("Remote Desktop Clients", "#RDCCheck") } }

        if ($global:msrdAVD -or $global:msrdRDS) { if ($varsAVDRDS[7]) { $BtnsAVDRDS.Add("Remote Desktop Licensing", "#LicCheck") } }

        if ($global:msrdTarget) { if ($varsAVDRDS[8]) { $BtnsAVDRDS.Add("Session Time Limits", "#STLCheck") } }

        if ($global:msrdAVD -or $global:msrdW365) { if ($varsAVDRDS[9]) { $BtnsAVDRDS.Add("Teams Media Optimization", "#TeamsCheck") } }

        if ($global:msrdW365) { if ($varsAVDRDS[10]) { $BtnsAVDRDS.Add("Windows 365 Boot", "#CPCCheck") } }

        if ($global:msrdRDS) {
            msrdHtmlMenu -htmloutfile $htmloutfile -CatText "RDS" -BtnTextAndId $BtnsAVDRDS
        } elseif ($global:msrdAVD) {
            msrdHtmlMenu -htmloutfile $htmloutfile -CatText "AVD/RDS" -BtnTextAndId $BtnsAVDRDS
        } elseif ($global:msrdW365) {
            msrdHtmlMenu -htmloutfile $htmloutfile -CatText "AVD/RDS/W365" -BtnTextAndId $BtnsAVDRDS
        }
    }

    #RD Infra
    if ($true -in $varsInfra) {

        if ($global:msrdAVD -or $global:msrdW365) {
            $BtnsRDInfra = [System.Collections.Generic.Dictionary[String,String]]@{}

            if ($global:msrdTarget) {
                if ($varsInfra[0]) { $BtnsRDInfra.Add("AVD Agents / SxS Stack", "#AgentStackCheck") }
                if ($global:msrdAVD) { if ($varsInfra[1]) { $BtnsRDInfra.Add("App Attach", "#AppAttachCheck") } }
                if ($varsInfra[2]) { $BtnsRDInfra.Add("AVD Services URI Health", "#BrokerURICheck") }
                if ($global:msrdAVD) { if ($varsInfra[3]) { $BtnsRDInfra.Add("Azure Stack HCI", "#HCICheck") } }
                if ($varsInfra[4]) { $BtnsRDInfra.Add("Health Checks", "#AVDHealthCheck") }
                if ($varsInfra[5]) { $BtnsRDInfra.Add("Host Pool", "#HPCheck") }
                if ($varsInfra[6]) { $BtnsRDInfra.Add("Monitoring", "#MonitorCheck")  }
            }

            if ($varsInfra[7]) { $BtnsRDInfra.Add("RDP Shortpath", "#UDPCheck") }
            if ($varsInfra[8] -or ($global:msrdW365 -and $varsInfra[9])) { $BtnsRDInfra.Add("Required Endpoints", "#URLCheck") }

            msrdHtmlMenu -htmloutfile $htmloutfile -CatText "RD Infra" -BtnTextAndId $BtnsRDInfra
        }
    }

    #ad
    if ($true -in $varsAD) {
        $BtnsAD = [System.Collections.Generic.Dictionary[String,String]]@{}

        if ($varsAD[0]) { $BtnsAD.Add("Domain", "#DCCheck") }
        if ($varsAD[1]) { $BtnsAD.Add("Microsoft Entra Join", "#AADJCheck") }

        msrdHtmlMenu -htmloutfile $htmloutfile -CatText "Active Directory" -BtnTextAndId $BtnsAD
    }

    #networking
    if ($true -in $varsNET) {
        $BtnsNet = [System.Collections.Generic.Dictionary[String,String]]@{}

        if ($varsNET[0]) { $BtnsNet.Add("Core NET", "#NWCCheck") }
        if ($varsNET[1]) { $BtnsNet.Add("DNS", "#DNSCheck") }
        if ($varsNET[2]) { $BtnsNet.Add("Firewall", "#FWCheck") }
        if ($varsNET[3]) { $BtnsNet.Add("IP Addresses", "#PublicIPCheck") }
        if ($varsNET[4]) { $BtnsNet.Add("Port Usage", "#PortUsageCheck") }
        if ($varsNET[5]) { $BtnsNet.Add("Proxy", "#ProxCheck") }
        if ($varsNET[6]) { $BtnsNet.Add("Routing", "#RoutingCheck") }
        if ($varsNET[7]) { $BtnsNet.Add("VPN", "#VPNCheck") }

        msrdHtmlMenu -htmloutfile $htmloutfile -CatText "Networking" -BtnTextAndId $BtnsNet
    }

    #logon/security
    if ($true -in $varsLogSec) {
        $BtnsLogSec = [System.Collections.Generic.Dictionary[String,String]]@{}

        if ($varsLogSec[0]) { $BtnsLogSec.Add("Authentication / Logon", "#AuthCheck") }
        if ($varsLogSec[1]) { $BtnsLogSec.Add("Security", "#SecCheck") }
        if ($varsLogSec[2]) { $BtnsLogSec.Add("Smart Card", "#SCardCheck") }

        msrdHtmlMenu -htmloutfile $htmloutfile -CatText "Logon / Security" -BtnTextAndId $BtnsLogSec
    }

    #known issues
    if ($true -in $varsIssues) {
        $BtnsIssues = [System.Collections.Generic.Dictionary[String,String]]@{}

        if ($varsIssues[0]) { $BtnsIssues.Add("Issues identified in Event Logs over the past 5 days", "#IssuesCheck") }
        if ($global:msrdTarget) { if ($varsIssues[1]) { $BtnsIssues.Add("Potential Logon/Logoff Issue Generators", "#BlackCheck") } }

        msrdHtmlMenu -htmloutfile $htmloutfile -CatText "Known Issues" -BtnTextAndId $BtnsIssues
    }

    #other
    if ($true -in $varsOther) {
        $BtnsOther = [System.Collections.Generic.Dictionary[String,String]]@{}

        if ($global:msrdTarget) {
            if ($varsOther[0]) { $BtnsOther.Add("Office", "#MSOCheck") }
            if ($varsOther[1]) { $BtnsOther.Add("OneDrive", "#MSODCheck") }
        }
        if ($varsOther[2]) { $BtnsOther.Add("Printing", "#PrintCheck") }
        if ($varsOther[3]) { $BtnsOther.Add("Third Party Software", "#3pCheck") }

        msrdHtmlMenu -htmloutfile $htmloutfile -CatText "Other" -BtnTextAndId $BtnsOther
    }
#endregion menu

msrdAddContentToHTML $htmloutfile "
            </div>

            <div class='right-aligned-text'><br><br>
                <span class='legend-label' id='legend-label'>Legend</span> | <div class='hide-show-all'><a href='#/' id='expAll' class='col' title='Hide/Show all categories'>Hide/Show All</a></div>
                <div class='legend-container' id='legend-container'>
                    <div class='legend-item'><span class='circle white'></span> Evaluate relevance in the current troubleshooting context</div>
                    <div class='legend-item'><span class='circle green'></span> Expected value/status [OK]</div>
                    <div class='legend-item'><span class='circle yellow'></span> Carefully evaluate, might lead to issues [Warning]</div>
                    <div class='legend-item'><span class='circle red'></span> Very likely to cause issues or error retrieving information [Critical]</div>
                    <div class='legend-item'><span class='circle-with-content info'></span> Hover for additional information</div>
                </div>
            </div>
        </div>
    </div>
    <div class='scroll'><table><tr><td>"
}

Function msrdHtmlBodyWU {
    Param ($htmloutfile, $title)

	msrdAddContentToHTML $htmloutfile "<body>
	<div class='WUtable-container'>
	<table>
		<tr><td style='text-align:center; padding-bottom: 10px;' colspan='6'><a name='TopDiag'></a><b><h2>$title</h2></b>

			<table>
				<tr>
					<td style='text-align:center;'><a href='#COM'><button class='menubutton'>Updates (COM)</button></a>&nbsp;
					<a href='#QFE'><button class='menubutton'>Other (QFE)</button></a>&nbsp;
					<a href='#REG'><button class='menubutton'>Other (Registry)</button></a></td>
				</tr>
			</table>
		</td></tr>

	<tr><td style='text-align:left; font-size: 13px; padding-bottom: 5px'><b>Operating System: $global:msrdOSVer</b></td><td align='right' style='height:5px;'><a href='#/' id='expAll' class='col'>Hide/Show All</a></td></tr>
	<tr><td colspan='2'>
	<details open>
		<summary>
			<a name='COM'></a><b>Microsoft.Update.Session</b><span class='b2top'><a href='#'>^top</a></span>
		</summary>
		<div class='detailsP'>
			<table class='tduo'>
				<tr style='text-align: left;'>
					<th width='10px'><div class='circle_no'></div></th><th style='padding-left: 5px;'>Category</th><th>Date/Time</th><th>Operation</th><th>Result</th><th>KB</th><th>Description</th>
				</tr>
	"
}

Function msrdHtmlEnd {
    Param ($htmloutfile)

    $dateTime = Get-Date
    $dateOnly = $dateTime.ToString("MMMM d, yyyy")
    $timeOnly = $dateTime.ToString("h:mm:ss tt")

    #html report footer
    msrdAddContentToHTML $htmloutfile "</tbody></table></div></details>
        </td></tr>
    </table>
    </div>

    <script type='text/javascript'>
        const xa = document.getElementById('expAll');

        xa.addEventListener('click', function(e) {
            e.currentTarget.classList.toggle('exp');
            e.currentTarget.classList.toggle('col');

            const details = document.querySelectorAll('details');

            Array.from(details).forEach(function(obj, idx) {
                if (e.currentTarget.classList.contains('exp')) {
                    obj.removeAttribute('open');
                } else {
                    obj.open = true;
                }
            });
        }, false);
    </script>

    <script>
    var legendLabel = document.getElementById('legend-label');
    var legendContainer = document.getElementById('legend-container');

    // Show the legend container on hover and update its position
    legendLabel.addEventListener('mouseover', function(event) {
        legendContainer.style.display = 'block';
        updateLegendPosition(event);
    });

    // Hide the legend container on mouseout
    legendLabel.addEventListener('mouseout', function() {
        legendContainer.style.display = 'none';
    });

    // Update legend container position based on mouse coordinates
    function updateLegendPosition(event) {
        var x = event.clientX + 10; // Add an offset to prevent the popup from overlapping with the cursor
        var y = event.clientY + 10;

        // Adjust x position to ensure the popup stays within the visible area
        var maxX = window.innerWidth - legendContainer.clientWidth;
        x = Math.min(x, maxX);

        legendContainer.style.left = x + 'px';
        legendContainer.style.top = y + 'px';
    }

    // Update legend position on mousemove
    legendLabel.addEventListener('mousemove', function(event) {
        updateLegendPosition(event);
    });
    </script>

    <script>
        document.getElementById('toggleButton').addEventListener('click', function() {
            const noGreenWhiteRows = document.querySelectorAll('tr td div.circle_no, tr td div.circle_green, tr td div.circle_white');

            noGreenWhiteRows.forEach(function(div) {
                const row = div.closest('tr');
                if (row) {
                    row.classList.toggle('hidden');
                }
            });

            const detailsSections = document.querySelectorAll('details');

            detailsSections.forEach(function(details) {
                const hasRedYellow = details.querySelector('tr td div.circle_red, tr td div.circle_yellow');

                if (!hasRedYellow) {
                    details.classList.toggle('hidden');
                }
            });
        });
    </script>

    <footer style='padding: 10px; font-size: 11px;'><i>Report generated on $dateOnly at $timeOnly - Script version $msrdVersion (Get the latest version from <a href='https://aka.ms/MSRD-Collect' target='_blank'>https://aka.ms/MSRD-Collect</a> - To provide feedback use <a href='https://aka.ms/MSRD-Collect-Feedback' target='_blank'>https://aka.ms/MSRD-Collect-Feedback</a>)</i><br>
    </footer>
    </body>
</html>"
}

Function msrdHtmlSetMenuWarning {
    param ($MenuCat, $MenuItem, $htmloutfile)

    #html report menu item warning
    if (Test-Path -path $htmloutfile) {

        $msrdDiagFileContent = Get-Content -Path $htmloutfile
        $msrdDiagFileReplace = foreach ($diagItem in $msrdDiagFileContent) {
            if ($diagItem -match "(.*>$MenuItem</a>)$") {
                $diagItem -replace $MenuItem, "$MenuItem <span style='color: red;'>&#9888;</span>"
            } elseif ($diagItem -match "(.*<button>$MenuCat</button>.*)") {
				$diagItem -replace $MenuCat, "$MenuCat <span style='color: red;'>&#9888;</span>"
            } else {
                $diagItem
            }
        }
        $msrdDiagFileReplace | Set-Content -Path $htmloutfile
    }
}

Function msrdHtmlSetIssueCounter {
    param ($htmloutfile)

    if (Test-Path -path $htmloutfile) {

        #Overview details are added at the end after all checks have been performed

        $OverviewMsg = "<details open><summary style='user-select: none;'><span style='position:relative;'><a name='Overview' style='position:absolute; top:-155px;'></a><b>Overview</b><span class='b2top'><a href='#'>^top</a></span></summary></span><div class='detailsP'><table class='tduo'><tbody>"

        if ($global:msrdIssueCounter -gt 0) {
            if ($global:msrdIssueCounter -eq 1) { $info = "source of potential problems has" } elseif ($global:msrdIssueCounter -gt 1) { $info = "sources of potential problems have" }
            $infoNOK1 = "<span style='color: red;'>$global:msrdIssueCounter</span> $info been identified."
            $infoNOK2 = "Review the menu items with a red exclamation mark [<span style='color: red;'>&#9888;</span>] and the corresponding lines throughout the report, marked with a red [<span class='circle_redCounter'></span>] or yellow [<span class='circle_yellowCounter'></span>] circle."
            $OverviewMsg += "<tr><td width='10px'><div class='circle_red'></div></td><td class='cTable2-1'' colspan='2'>$infoNOK1</td><td><a href='#/' id='toggleButton' title='Toggle line view (Show all / only potential problems)'>Toggle line view (Show all / only potential problems)</a></td></tr>
<tr><td width='10px'><div class='circle_no'></div></td><td class='cText' colspan='3'>$infoNOK2</td></tr>"

        } else {
            $infoOK = "No sources of potential problems have been identified."
            $OverviewMsg += "<tr><td width='10px'><div class='circle_green'></div></td><td class='cText' colspan='3'>$infoOK</td></tr>"
        }

        $infoAdd1 = "A thorough overview of all the results (even if not automatically flagged) is highly recommended, considering the context of the investigation."
        $infoAdd2 = "Some settings may work perfectly well in most scenarios and cause issues only in specific situations, and as such may not be automatically identified as problematic."
        $OverviewMsg += "<tr><td width='10px'><div class='circle_no'></div></td><td class='cText' colspan='3'>$infoAdd1</td></tr>
<tr><td width='10px'><div class='circle_no'></div></td><td class='cText' colspan='3'>$infoAdd2</td></tr>
</tbody></table></div></details>"

        $msrdDiagFileContent = Get-Content -Path $htmloutfile
        $msrdDiagFileReplace = foreach ($diagItem in $msrdDiagFileContent) {
            if ($diagItem -match "<div class='scroll'><table><tr><td>") {
                $diagItem -replace $diagItem, "$diagItem $OverviewMsg"
            } else {
                $diagItem
            }
        }
        $msrdDiagFileReplace | Set-Content -Path $htmloutfile
    }
}

#endregion HTML functions

Export-ModuleMember -Function *

# SIG # Begin signature block
# MIInwQYJKoZIhvcNAQcCoIInsjCCJ64CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDXdmkuuRfLPHYf
# 4pJKx+nzI5enVivMEXnANWpv2FeFWKCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGaEwghmdAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPzhJYH1H7wB8OmVE57idNCD
# Bu0bxG1nmu783IkiFKqGMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAV/KY01N8kGoBFEm/uu7GOqy6BfUt8wMmzHx6XHgNSDfdNaD8s1xWvbQ9
# CjHV1k9wWEGdHUeJb/nWtxxYw1ISNCnQG6SEweAG4xMNXeolXm0UFSRXOZFDlTTC
# h07SOZsnlIEMwwK/RtW4OTemo1f1QaHLR7Kg2zXERLv7NEU7pbpElU/NdnhA1hgF
# TbReNwCw/t0bSI+7NOfjXJ81NYK1ktD/YUZ0q4i4SrmovvEltTJKl2GxhQipx7n4
# HmCUSJMOGuUK3nvRkt3qjypWsjnTqFm4jDwCuA/nwIFKF8LXbMCbXCN1cUNqdO+r
# CIg512Nh2nNX0iBNebH8bP19DgZ0RqGCFyswghcnBgorBgEEAYI3AwMBMYIXFzCC
# FxMGCSqGSIb3DQEHAqCCFwQwghcAAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFYBgsq
# hkiG9w0BCRABBKCCAUcEggFDMIIBPwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCAwtv6s4gg2e0rlAcN2B0iVn+s7a7UOvn9AQ6gcxF3inQIGZsXwyeOi
# GBIyMDI0MDkwOTEwMjEzMC4zM1owBIACAfSggdikgdUwgdIxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVs
# YW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046
# MTc5RS00QkIwLTgyNDYxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNl
# cnZpY2WgghF7MIIHJzCCBQ+gAwIBAgITMwAAAeDU/B8TFR9+XQABAAAB4DANBgkq
# hkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMzEw
# MTIxOTA3MTlaFw0yNTAxMTAxOTA3MTlaMIHSMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVy
# YXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjE3OUUtNEJC
# MC04MjQ2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEArIec86HFu9EBOcaNv/p+4GGH
# dkvOi0DECB0tpn/OREVR15IrPI23e2qiswrsYO9xd0qz6ogxRu96eUf7Dneyw9rq
# tg/vrRm4WsAGt+x6t/SQVrI1dXPBPuNqsk4SOcUwGn7KL67BDZOcm7FzNx4bkUMe
# sgjqwXoXzv2U/rJ1jQEFmRn23f17+y81GJ4DmBSe/9hwz9sgxj9BiZ30XQH55sVi
# L48fgCRdqE2QWArzk4hpGsMa+GfE5r/nMYvs6KKLv4n39AeR0kaV+dF9tDdBcz/n
# +6YE4obgmgVjWeJnlFUfk9PT64KPByqFNue9S18r437IHZv2sRm+nZO/hnBjMR30
# D1Wxgy5mIJJtoUyTvsvBVuSWmfDhodYlcmQRiYm/FFtxOETwVDI6hWRK4pzk5Znb
# 5Yz+PnShuUDS0JTncBq69Q5lGhAGHz2ccr6bmk5cpd1gwn5x64tgXyHnL9xctAw6
# aosnPmXswuobBTTMdX4wQ7wvUWjbMQRDiIvgFfxiScpeiccZBpxIJotmi3aTIlVG
# wVLGfQ+U+8dWnRh2wIzN16LD2MBnsr2zVbGxkYQGsr+huKlfq7GMSnJQD2ZtU+WO
# VvdHgxYjQTbEj80zoXgBzwJ5rHdhYtP5pYJl6qIgwvHLJZmD6LUpjxkTMx41MoIQ
# jnAXXDGqvpPX8xCj7y0CAwEAAaOCAUkwggFFMB0GA1UdDgQWBBRwXhc/bp1X7xK6
# ygDVddDZMNKZ0jAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNV
# HR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2Ny
# bC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYI
# KwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAy
# MDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMI
# MA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAwBPODpH8DSV07syo
# bEPVUmOLnJUDWEdvQdzRiO2/taTFDyLB9+W6VflSzri0Pf7c1PUmSmFbNoBZ/bAp
# 0DDflHG1AbWI43ccRnRfbed17gqD9Z9vHmsQeRn1vMqdH/Y3kDXr7D/WlvAnN19F
# yclPdwvJrCv+RiMxZ3rc4/QaWrvS5rhZQT8+jmlTutBFtYShCjNjbiECo5zC5Fyb
# oJvQkF5M4J5EGe0QqCMp6nilFpC3tv2+6xP3tZ4lx9pWiyaY+2xmxrCCekiNsFrn
# m0d+6TS8ORm1sheNTiavl2ez12dqcF0FLY9jc3eEh8I8Q6zOq7AcuR+QVn/1vHDz
# 95EmV22i6QejXpp8T8Co/+yaYYmHllHSmaBbpBxf7rWt2LmQMlPMIVqgzJjNRLRI
# RvKsNn+nYo64oBg2eCWOI6WWVy3S4lXPZqB9zMaOOwqLYBLVZpe86GBk2YbDjZIU
# HWpqWhrwpq7H1DYccsTyB57/muA6fH3NJt9VRzshxE2h2rpHu/5HP4/pcq06DIKp
# b/6uE+an+fsWrYEZNGRzL/+GZLfanqrKCWvYrg6gkMlfEWzqXBzwPzqqVR4aNTKj
# uFXLlW/ID7LSYacQC4Dzm2w5xQ+XPBYXmy/4Hl/Pfk5bdfhKmTlKI26WcsVE8zlc
# KxIeq9xsLxHerCPbDV68+FnEO40wggdxMIIFWaADAgECAhMzAAAAFcXna54Cm0mZ
# AAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMyMjVa
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0BAQEF
# AAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1
# V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9
# alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9cmmv
# Haus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN7928
# jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDuaRr3t
# pK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74kpEe
# HT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2K26o
# ElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5TI4C
# vEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZki1ug
# poMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9QBXps
# xREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3PmriLq0C
# AwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYE
# FCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJlpxtT
# NRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIBFjNo
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5o
# dG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBD
# AEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZW
# y4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0y
# My5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pc
# FLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulmZzpT
# Td2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM9W0j
# VOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3
# +SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4FOmR
# sqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSw
# ethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPXfx5b
# RAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVXVAmx
# aQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGConsX
# HRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0
# W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEGahC0
# HVUzWLOhcGbyoYIC1zCCAkACAQEwggEAoYHYpIHVMIHSMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjE3
# OUUtNEJCMC04MjQ2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloiMKAQEwBwYFKw4DAhoDFQBt89HV8FfofFh/I/HzNjMlTl8hDKCBgzCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA
# 6ojSFDAiGA8yMDI0MDkwOTA5NDcwMFoYDzIwMjQwOTEwMDk0NzAwWjB3MD0GCisG
# AQQBhFkKBAExLzAtMAoCBQDqiNIUAgEAMAoCAQACAgpfAgH/MAcCAQACAhE+MAoC
# BQDqiiOUAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAJbx4J37MH1RjdZ4F
# C2f2fjUEZv3IHuRT12Db/CYEXC/tNpBK5jpv/Hgb5vNJ5GXQ4tzplur8jHxzjkS3
# ogi3Fx+rc/1VaimIfB+fOReob0uZOQvIACt7CBWyP7Am1j/FyK3Cz5A/KAOBGXrc
# jXy/sM/QBA/MY3BZFITNOa0NrX8xggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMAITMwAAAeDU/B8TFR9+XQABAAAB4DANBglghkgBZQME
# AgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJ
# BDEiBCD6AR/albWuRHZmv3VIA5stiFTq1Ycuulyw0uAGvHIpGzCB+gYLKoZIhvcN
# AQkQAi8xgeowgecwgeQwgb0EIOPuUr/yOeVtOM+9zvsMIJJvhNkClj2cmbnCGwr/
# aQrBMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHg
# 1PwfExUffl0AAQAAAeAwIgQgS11NOvyrUBCpRyc+NDIC9yV6WcImJo+zD/Ros4l0
# U14wDQYJKoZIhvcNAQELBQAEggIAD8K3uFbkkeEz8Es+Wyn0FTUtQk63orrf8aKi
# nW00AEOxBo8fs/QcpvXQ5OtKQK8MnqXy62hCjCfoJ/y/qq/pgGZTQAkkK+K1a5z1
# fNXfftBmGpFQksY/OwMRP1veqnQkugNpFYWJ9zu2iIS2M02684XF+ZAuX2s2lrov
# Wk1UnJM1ZEXd9miO3q2nviQFzSxmQdewYa0ocfluf9u3N7B3eGS1knnfe0bpguus
# IPRS/05feMaX7JxpbjEZvda7sVG1l9zjGbOA62FA9mTjQSA3DEEJqk7mQD+bcenq
# JwVY2NE7CrhYNGlZgbyEa4hkDbtFhHWYOrSPgUk8qY9mktVbrEQDyWmIUSWKvn0g
# AvJ/Ltde5E9a2InssLAFTLfPIJ9QADOo18e1PJSlgDw7cGeb4JnIglgBhKPMq3hy
# V5PRySabOuV8ELK9RmLnVJgmjLFQcDk6t/OHATU5fqt6oiaPFZMx1wKsyLIQXGX6
# pLIy430Koe9y9RnsofiBzcVKWYzC/DTd5eHJfKMoIxFdJKTXex/zxV8PRtVaZJ6H
# FE/RtIqpNjgaVq8D2ptYiMeFYCYUS5VCVRQfO+yDBaqN3gtFU3ZTocoC3LRptQXN
# YQ9sjubd05gbpSnaBECTvCH9oqpr4xY/79R/P6Sl03Ju3DHCst+W/Ol73c8bR4cI
# QuwpOwU=
# SIG # End signature block
